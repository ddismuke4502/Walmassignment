//
//  Network+JSONDecoder.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/5/25.
//

import Foundation

extension JsonDecoder {
    func decode<T>(type: T.Type, data: Data) throws -> T where T : Decodable {
        return try JSONDecoder().decode(type.self, from: data)
    }
}

extension Network: NetworkingProtocol, JsonDecoder {
    func get<T>(apiURL: String, type: T.Type) async throws -> T where T : Decodable {
        guard let url = URL(string: apiURL) else {
            throw ErrorCases.urlError
        }
        let (data, _) = try await self.session.data(from: url, delegate: nil)
       return try decode(type:type, data: data)
    }
}

extension URLSession:NetworkingSession{
    func data(for request: URLRequest, delegate: (any URLSessionDelegate)?) async throws -> (Data, URLResponse) {
        try await self.data(for: request)
    }
}
