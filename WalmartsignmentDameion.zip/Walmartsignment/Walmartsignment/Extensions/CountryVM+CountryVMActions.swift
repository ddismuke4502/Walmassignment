//
//  CountryVM+CountryVMActions.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/5/25.
//

import Foundation

extension ViewModel: CountryVMActions {
    func getCountryList(_ urlString: String) async {
        do {
            let countryData = try await networkManager.get(apiURL: urlString, type: Countries.self)
            self.countries = countryData
            self.filteredCountryList = countryData
            print(self.countries)
            delegate?.refreshUI()
        } catch let error {
            print(error.localizedDescription)
        }
    }

    func searchCountryList(with searchText: String){
        filteredCountryList = searchText == "" ? countries: countries.filter{
            ($0.name.lowercased().starts(with: searchText.lowercased()) || $0.capital.lowercased().starts(with: searchText.lowercased()))
        }
    }
}
