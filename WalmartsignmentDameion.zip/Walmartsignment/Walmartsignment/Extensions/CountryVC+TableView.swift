//
//  VC+TableView.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/5/25.
//

import UIKit

extension CountryVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.filteredCountryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCellID", for: indexPath) as! TableCell
        
        let country = viewModel.filteredCountryList[indexPath.row]
        
        cell.nameLabel.text = "\(country.name), \(country.region.rawValue)"
        cell.capitalLabel.text = country.capital
        cell.codeLabel.text = country.code
        
        return cell
    }
}

extension CountryVC: CountryVCActions {
    func refreshUI() {
        reloadTableViewWithData()
    }
}

extension CountryVC: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        let searchWord = searchController.searchBar.text ?? ""
        viewModel.searchCountryList(with: searchWord)
        reloadTableViewWithData()
    }
}
