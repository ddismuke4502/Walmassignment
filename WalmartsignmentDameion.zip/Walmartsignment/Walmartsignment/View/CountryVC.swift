//
//  CountryVC.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/5/25.
//

import UIKit

class CountryVC: UIViewController, UISearchControllerDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var viewModel = ViewModel(networkManager: Network())
    let searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        viewModel.delegate = self
        navigationItem.searchController = searchController
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        
        Task {
            await viewModel.getCountryList(Endpoints.Endpoint)
        }
    }
    
    func reloadTableViewWithData(){
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
}
