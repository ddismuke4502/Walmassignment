//
//  Network.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/5/25.
//

import Foundation

struct Network {
    var session: NetworkingSession
    init(session: NetworkingSession = URLSession.shared) {
        self.session = session
    }
}
