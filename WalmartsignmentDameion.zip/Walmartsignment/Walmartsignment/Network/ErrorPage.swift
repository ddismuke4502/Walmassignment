//
//  ErrorPage.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/5/25.
//

import Foundation

enum ErrorCases: Error {
    case invalidResponse
    case urlError
    case serverNotFoundError
    case dataNotFound
}
