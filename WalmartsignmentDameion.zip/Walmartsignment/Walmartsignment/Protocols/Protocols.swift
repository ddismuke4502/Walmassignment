//
//  Protocols.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/5/25.
//

import Foundation

protocol JsonDecoder {
    func decode<T: Decodable>(type: T.Type, data: Data) throws -> T
}

protocol NetworkingProtocol {
    func get<T: Decodable>(apiURL: String, type: T.Type) async throws -> T
}

protocol CountryVMActions {
    func getCountryList(_ urlString: String) async
    func searchCountryList(with searchText:String)
}

protocol CountryVCActions:AnyObject{
    func refreshUI()
}
protocol NetworkingSession {
    func data(from url: URL, delegate: (any URLSessionTaskDelegate)?) async throws -> (Data, URLResponse)
}
