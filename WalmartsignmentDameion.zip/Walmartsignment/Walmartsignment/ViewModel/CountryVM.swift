//
//  CountryVM.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/5/25.
//

import Foundation

final class ViewModel: ObservableObject {
    
    var countries: [Country] = []
    var filteredCountryList: [Country] = []

    weak var delegate: CountryVCActions?
    let networkManager: NetworkingProtocol
    
    init(networkManager: NetworkingProtocol = Network()) {
        self.networkManager = networkManager
    }
}
