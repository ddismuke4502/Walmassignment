//
//  NetworkTests.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/6/25.
//

import XCTest
@testable import Walmartsignment

private struct Dummy: Decodable {
    let id: Int
}

final class NetworkingTests: XCTestCase {
    
    
    func testNetworkManagerGetDataFromAPI_WhenEverythingISCorrect() async throws {
    
        //Given
        let mockUrlSession = MockUrlSession()
        let networkManager = Network(session: mockUrlSession)
        
        do{
            //When
            let json = """
            [
                {
                    \"name\": \"Testland\",
                    \"capital\": \"Test City\",
                    \"code\": \"TL\",
                    \"currency\": {
                        \"code\": \"TD\",
                        \"name\": \"Test Dollar\",
                        \"symbol\": \"$\"
                    },
                    \"flag\": \"🏳️\",
                    \"language\": {
                        \"code\": \"en\",
                        \"name\": \"English\",
                        \"iso639_2\": \"eng\",
                        \"nativeName\": \"English\"
                    },
                    \"region\": \"EU\",
                    \"demonym\": \"Testlander\"
                }
            ]
            """
            let dummyData = Data(json.utf8)
            mockUrlSession.setMockData(mockData: dummyData)
            
            let urlResponse = HTTPURLResponse(url: URL(string: "test")!, statusCode: 200, httpVersion: nil, headerFields: nil)
            mockUrlSession.setUrlResponse(urlResponse: urlResponse!)
            
            let data = try await networkManager.get(apiURL: "test", type: [Country].self)
            
            //Then
            XCTAssertNotNil(data)
        }catch{
            XCTAssertNil(error)
        }
    }
    
    func testNetworkManagerGetDataFromAPI_WhenItGives404Error() async throws {
    
        //Given
        let mockUrlSession = MockUrlSession()
        let networkManager = Network(session: mockUrlSession)

        do{
            //When
            let dummyData = "SomeDummyTestData".data(using: .utf8)
            mockUrlSession.setMockData(mockData: dummyData!)
            mockUrlSession.setError(error: ErrorCases.invalidResponse)

            
            let urlResponse = HTTPURLResponse(url: URL(string: "test")!, statusCode: 404, httpVersion: nil, headerFields: nil)
            mockUrlSession.setUrlResponse(urlResponse: urlResponse!)
            
            let _ = try await networkManager.get(apiURL: "test", type: [Country].self)
        }catch{
            XCTAssertEqual(error as! ErrorCases, ErrorCases.invalidResponse)
        }
    }

    
    func testNetworkManagerGetDataFromAPI_WhenRequestIsInvalid() async throws {
    
        //Given
        let mockUrlSession = MockUrlSession()
        let networkManager = Network(session: mockUrlSession)

        do{
            //When
            let _ = try await networkManager.get(apiURL: "", type: [Country].self)
        }catch{
            XCTAssertEqual(error as! ErrorCases, ErrorCases.urlError)
        }
    }
    func testNetworkManagerGetDataFromAPI_WhenWeGetDataNotFoundError() async throws {
    
        //Given
        let mockUrlSession = MockUrlSession()
        let networkManager = Network(session: mockUrlSession)

        do{
            //When
            mockUrlSession.setError(error: ErrorCases.dataNotFound)
            let _ = try await networkManager.get(apiURL: "test", type: [Country].self)
        }catch{
            XCTAssertEqual(error as! ErrorCases, ErrorCases.dataNotFound)
        }
    }
    
    
    // Verifies if the JsonDecoder extension decodes valid JSON correctly
    func testJsonDecoderDecodeSuccess() throws {
        let network = Network()
        let json = "{ \"id\": 123 }"
        let data = Data(json.utf8)

        let decoded: Dummy = try network.decode(type: Dummy.self, data: data)
        XCTAssertEqual(decoded.id, 123)
    }

    // Verifies if the JsonDecoder extension throws when JSON is invalid
    func testJsonDecoderDecodeThrowsOnInvalidJSON() throws {
        let network = Network()
        let invalidJson = "{ \"wrongKey\": 123 }"
        let data = Data(invalidJson.utf8)

        XCTAssertThrowsError(try network.decode(type: Dummy.self, data: data))
    }

    // Verifies if the Endpoint matches
    func testServiceEndpointConstant() {
        XCTAssertEqual(Endpoints.Endpoint,
                       "https://gist.githubusercontent.com/peymano-wmt/32dcb892b06648910ddd40406e37fdab/raw/db25946fd77c5873b0303b858e861ce724e0dcd0/countries.json")
    }
}
