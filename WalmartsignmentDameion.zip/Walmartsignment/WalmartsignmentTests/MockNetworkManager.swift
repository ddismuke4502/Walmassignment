//
//  MockNetworkManager.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/6/25.
//

import XCTest
@testable import Walmartsignment

class MockNetworkManager: NetworkingProtocol {
    var countriesResult: Countries?
    var shouldThrowError = false

    func get<T>(apiURL: String, type: T.Type) async throws -> T where T: Decodable {
        if shouldThrowError {
            throw ErrorCases.invalidResponse
        }
        // Force-cast because we control type in the tests
        guard let result = countriesResult as? T else {
            fatalError("Type mismatch in mock result")
        }
        return result
    }
}
