//
//  CountryVMTests.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/6/25.
//

import XCTest
@testable import Walmartsignment

final class ViewModelTests: XCTestCase {
    var viewModel: ViewModel!
    var mockNetwork: MockNetworkManager!

    override func setUp() {
        super.setUp()
        mockNetwork = MockNetworkManager()
        viewModel = ViewModel(networkManager: mockNetwork)
    }

    override func tearDown() {
        viewModel = nil
        mockNetwork = nil
        super.tearDown()
    }

    // Tests successful fetches of country list triggering UI refresh and assigns data
    func testGetCountryListSuccess() async throws {
        // Samples
        let sampleCountry = Country(
            capital: "Test City",
            code: "TL",
            currency: Currency(code: "TD", name: "Test Dollar", symbol: "$"),
            flag: "🏳️",
            language: Language(code: "en", name: "English", iso6392: "eng", nativeName: "English"),
            name: "Testland",
            region: .eu,
            demonym: "Testlander"
        )
        let sampleCountries: Countries = [sampleCountry]
        mockNetwork.countriesResult = sampleCountries

        // Performs fetch
        await viewModel.getCountryList("dummyURL")

        // Verifies assignments and delegate call
        XCTAssertEqual(viewModel.countries, sampleCountries)
        XCTAssertEqual(viewModel.filteredCountryList, sampleCountries)
    }

    // Tests handling of network failure
    func testGetCountryListFailure() async throws {
        mockNetwork.shouldThrowError = true

        // Fetches on failure
        await viewModel.getCountryList("dummyURL")

        // Should be no changes
        XCTAssertTrue(viewModel.countries.isEmpty)
        XCTAssertTrue(viewModel.filteredCountryList.isEmpty)
    }

    // Tests the search of empty string resets filtered list to full data
    func testSearchCountryListEmptySearch() async{
        let sampleCountries: Countries = [
            Country(
                capital: "CityA",
                code: "A",
                currency: Currency(code: "C1", name: "Coin1", symbol: nil),
                flag: "🇦",
                language: Language(code: nil, name: "LangA", iso6392: nil, nativeName: nil),
                name: "Alpha",
                region: .americas,
                demonym: "Alphan"
            ),
            Country(
                capital: "CityB",
                code: "B",
                currency: Currency(code: "C2", name: "Coin2", symbol: nil),
                flag: "🇧",
                language: Language(code: nil, name: "LangB", iso6392: nil, nativeName: nil),
                name: "Beta",
                region: .af,
                demonym: nil
            )
        ]
        mockNetwork.countriesResult = sampleCountries

        // Performs fetch
        await viewModel.getCountryList("dummyURL")

        viewModel.searchCountryList(with: "")

        XCTAssertEqual(viewModel.filteredCountryList.count, sampleCountries.count)
        XCTAssertEqual(viewModel.filteredCountryList, sampleCountries)

    }

    // Tests a case-insensitive search filters by name and capital
    func testSearchCountryListFiltersByNameOrCapital() async{
        let sampleCountries: Countries = [
            Country(
                capital: "MatchCity",
                code: "M",
                currency: Currency(code: "C", name: "Coin", symbol: nil),
                flag: "🚩",
                language: Language(code: nil, name: "Lang", iso6392: nil, nativeName: nil),
                name: "Country",
                region: .eu,
                demonym: nil
            ),
            Country(
                capital: "CityX",
                code: "X",
                currency: Currency(code: "C", name: "Coin", symbol: nil),
                flag: "🚩",
                language: Language(code: nil, name: "Lang", iso6392: nil, nativeName: nil),
                name: "Xenon",
                region: .eu,
                demonym: nil
            )
        ]
        mockNetwork.countriesResult = sampleCountries

        // Performs fetch
        await viewModel.getCountryList("dummyURL")

        viewModel.searchCountryList(with: "Match")
        XCTAssertEqual(viewModel.filteredCountryList.count, 1)
        XCTAssertEqual(viewModel.filteredCountryList.first?.capital, "MatchCity")

        viewModel.searchCountryList(with: "xe")
        XCTAssertEqual(viewModel.filteredCountryList.count, 1)
        XCTAssertEqual(viewModel.filteredCountryList.first?.name, "Xenon")
    }

    // Tests searches with no matching results and empty list
    func testSearchCountryListNoMatches() async{
        let sampleCountries: Countries = [
            Country(
                capital: "CityA",
                code: "A",
                currency: Currency(code: "C1", name: "Coin1", symbol: nil),
                flag: "🇦",
                language: Language(code: nil, name: "LangA", iso6392: nil, nativeName: nil),
                name: "Alpha",
                region: .americas,
                demonym: "Alphan"
            )
        ]
        mockNetwork.countriesResult = sampleCountries

        // Performs fetch
        await viewModel.getCountryList("dummyURL")


        viewModel.searchCountryList(with: "zzz")
        XCTAssertTrue(viewModel.filteredCountryList.isEmpty)
    }
}
