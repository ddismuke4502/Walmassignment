//
//  MockUrlSession.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/6/25.
//

import XCTest
@testable import Walmartsignment

class MockUrlSession:NetworkingSession{

    private var mockData:Data!
    private var urlResponse:URLResponse!
    private var error:Error?
    
    func data(from url: URL, delegate: (any URLSessionTaskDelegate)?) async throws -> (Data, URLResponse) {
        if error != nil{
            throw error!
        }
        return (mockData,urlResponse)
    }
    
    
    func setMockData(mockData:Data){
        self.mockData = mockData
    }
    
    func setUrlResponse(urlResponse:URLResponse){
        self.urlResponse = urlResponse
    }
    
    func setError(error:Error){
        self.error = error
    }
}
