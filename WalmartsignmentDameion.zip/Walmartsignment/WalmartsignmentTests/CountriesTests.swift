//
//  CountriesTests.swift
//  Walmartsignment
//
//  Created by Dameion Dismuke on 5/6/25.
//

import XCTest
@testable import Walmartsignment

// Tests for the Countries model and its JSON decoding behavior
final class CountriesTests: XCTestCase {
    func testDecodingSingleCountry() throws { // Verifies if a single Country instance decodes correctly when all fields are present
        let json = """
        [
            {
                \"name\": \"Testland\",
                \"capital\": \"Test City\",
                \"code\": \"TL\",
                \"currency\": {
                    \"code\": \"TD\",
                    \"name\": \"Test Dollar\",
                    \"symbol\": \"$\"
                },
                \"flag\": \"🏳️\",
                \"language\": {
                    \"code\": \"en\",
                    \"name\": \"English\",
                    \"iso639_2\": \"eng\",
                    \"nativeName\": \"English\"
                },
                \"region\": \"EU\",
                \"demonym\": \"Testlander\"
            }
        ]
        """
        let data = Data(json.utf8)
        let countries = try JSONDecoder().decode(Countries.self, from: data)
        XCTAssertEqual(countries.count, 1)

        let country = countries[0]
        XCTAssertEqual(country.name, "Testland")
        XCTAssertEqual(country.capital, "Test City")
        XCTAssertEqual(country.code, "TL")
        XCTAssertEqual(country.flag, "🏳️")
        XCTAssertEqual(country.demonym, "Testlander")
        XCTAssertEqual(country.region, .eu)

        // Currency fields
        XCTAssertEqual(country.currency.code, "TD")
        XCTAssertEqual(country.currency.name, "Test Dollar")
        XCTAssertEqual(country.currency.symbol, "$")

        // Language and CodingKeys mapping
        XCTAssertEqual(country.language.code, "en")
        XCTAssertEqual(country.language.name, "English")
        XCTAssertEqual(country.language.iso6392, "eng")
        XCTAssertEqual(country.language.nativeName, "English")
    }

    func testDecodingOptionalFields() throws { // Verifies decoding when optional fields are null or missing
        let json = """
        [
            {
                \"name\": \"Optionalia\",
                \"capital\": \"Opt City\",
                \"code\": \"OP\",
                \"currency\": {
                    \"code\": \"OC\",
                    \"name\": \"Opt Coin\",
                    \"symbol\": null
                },
                \"flag\": \"🚩\",
                \"language\": {
                    \"name\": \"Optish\"
                },
                \"region\": \"\",
                \"demonym\": null
            }
        ]
        """
        let data = Data(json.utf8)
        let countries = try JSONDecoder().decode(Countries.self, from: data)
        XCTAssertEqual(countries.count, 1)

        let country = countries[0]
        XCTAssertEqual(country.name, "Optionalia")
        XCTAssertEqual(country.capital, "Opt City")
        XCTAssertEqual(country.code, "OP")
        XCTAssertEqual(country.flag, "🚩")
        XCTAssertNil(country.demonym)
        XCTAssertEqual(country.region, .empty)

        // Currency symbol should be nil when JSON null
        XCTAssertEqual(country.currency.code, "OC")
        XCTAssertEqual(country.currency.name, "Opt Coin")
        XCTAssertNil(country.currency.symbol)

        // Language optional properties should be nil
        XCTAssertNil(country.language.code)
        XCTAssertEqual(country.language.name, "Optish")
        XCTAssertNil(country.language.iso6392)
        XCTAssertNil(country.language.nativeName)
    }
}
